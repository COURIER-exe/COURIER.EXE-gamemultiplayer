<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Interiors_32x32" tilewidth="32" tileheight="32" tilecount="17024" columns="16">
 <image source="../../.cache/.fr-PAVQV3/1_Interiors/32x32/Interiors_32x32.png" width="512" height="34048"/>
</tileset>
