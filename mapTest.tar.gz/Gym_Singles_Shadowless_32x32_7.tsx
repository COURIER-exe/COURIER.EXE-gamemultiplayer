<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Gym_Singles_Shadowless_32x32_7" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="../.cache/.fr-93HKV3/1_Interiors/32x32/Theme_Sorter_Shadowless_Singles_32x32/8_Gym_Singles_Shadowless_32x32/Gym_Singles_Shadowless_32x32_7.png" width="32" height="32"/>
</tileset>
