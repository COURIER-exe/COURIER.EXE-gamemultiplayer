<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="Living_Room_Singles_Shadowless_32x32_1" tilewidth="32" tileheight="32" tilecount="6" columns="2">
 <image source="1_Interiors/32x32/Theme_Sorter_Shadowless_Singles_32x32/2_Living_Room_Singles_Shadowless_32x32/Living_Room_Singles_Shadowless_32x32_1.png" width="64" height="96"/>
</tileset>
